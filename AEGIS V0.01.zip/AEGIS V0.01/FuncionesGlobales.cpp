#include <iostream>
using namespace std;
#include <cstdlib>
#include <cstring>
#include "PrototiposGlobales.h"

