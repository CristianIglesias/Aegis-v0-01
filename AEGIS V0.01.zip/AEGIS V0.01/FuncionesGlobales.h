#ifndef FUNCIONESGLOBALES_H_INCLUDED
#define FUNCIONESGLOBALES_H_INCLUDED
#pragma once
#include <cstring>



#endif // FUNCIONESGLOBALES_H_INCLUDED
