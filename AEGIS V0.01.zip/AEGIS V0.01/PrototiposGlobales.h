#ifndef PROTOTIPOSGLOBALES_H_INCLUDED
#define PROTOTIPOSGLOBALES_H_INCLUDED
#pragma once
struct Fecha
{
    int dia,mes,anio;
};




#endif // PROTOTIPOSGLOBALES_H_INCLUDED
