#include <iostream>
using namespace std;
#include "Persona.h"
#include "Vendedor.h"
const char *ArchivoVendedor ="Vendedor.dat";
#include "PrototiposGlobales.h"
///escribiendo para modificar todos los cosos en el proximo push

