#include <iostream>
using namespace std;
#include "FuncionesGlobales.h"
#include "Ventas.h"
const char *ArchivoVenta ="Ventas.dat";
